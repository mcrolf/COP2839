﻿namespace CarDealershipApp.Models
{
    public class Lot
    {
        //******************************************
        // define attributes for lot
        //******************************************
        public int LotID { get; set; }
        public string? LotName { get; set; }
        public string? LotAddress { get; set; }
    }
}
