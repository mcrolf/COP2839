﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace VideoGameStore.Models
{
    internal class GameConfiguration : IEntityTypeConfiguration<Game>
    {
        public void Configure(EntityTypeBuilder<Game> builder)
        {
            builder.HasData(
                new Game
                {
                    GameId = 1,
                    Title = "The Witcher 3: Wild Hunt",
                    GenreId = 3,
                    PublisherId = 2,
                    ReleaseDate = new DateTime(2015, 5, 19),
                    Platform = Platform.Computer,
                    Price = 29.99m,
                    StockQuantity = 100
                },

                new Game
                {
                    GameId = 2,
                    Title = "Red Dead Redemption 2",
                    GenreId = 4,
                    PublisherId = 2,
                    ReleaseDate = new DateTime(2018, 10, 26),
                    Platform = Platform.Playstation,
                    Price = 39.99m,
                    StockQuantity = 75
                },

                new Game
                {
                    GameId = 3,
                    Title = "The Legend of Zelda: Breath of the Wild",
                    GenreId = 4,
                    PublisherId = 3,
                    ReleaseDate = new DateTime(2017, 3, 3),
                    Platform = Platform.Ninetndo_Switch,
                    Price = 49.99m,
                    StockQuantity = 60
                },

                new Game
                {
                    GameId = 4,
                    Title = "Cyberpunk 2077",
                    GenreId = 3,
                    PublisherId = 1,
                    ReleaseDate = new DateTime(2020, 12, 10),
                    Platform = Platform.Xbox,
                    Price = 34.99m,
                    StockQuantity = 90
                },

                new Game
                {
                    GameId = 5,
                    Title = "Minecraft",
                    GenreId = 1,
                    PublisherId = 6,
                    ReleaseDate = new DateTime(2011, 11, 18),
                    Platform = Platform.Playstation_5,
                    Price = 19.99m,
                    StockQuantity = 120
                },

                new Game
                {
                    GameId = 6,
                    Title = "FIFA 22",
                    GenreId = 5,
                    PublisherId = 5,
                    ReleaseDate = new DateTime(2021, 10, 1),
                    Platform = Platform.Xbox,
                    Price = 44.99m,
                    StockQuantity = 80
                },

                 new Game
                 {
                     GameId = 7,
                     Title = "Assassin's Creed Valhalla",
                     GenreId = 3,
                     PublisherId = 4,
                     ReleaseDate = new DateTime(2020, 11, 10),
                     Platform = Platform.Playstation_4,
                     Price = 37.99m,
                     StockQuantity = 70
                 },

                new Game
                {
                    GameId = 8,
                    Title = "Call of Duty: Warzone",
                    GenreId = 2,
                    PublisherId = 7,
                    ReleaseDate = new DateTime(2020, 3, 10),
                    Platform = Platform.Computer,
                    Price = 0.99m,
                    StockQuantity = 150
                },

                new Game
                {
                    GameId = 9,
                    Title = "Super Mario Odyssey",
                    GenreId = 6,
                    PublisherId = 3,
                    ReleaseDate = new DateTime(2017, 10, 27),
                    Platform = Platform.Ninetndo_Switch,
                    Price = 44.99m,
                    StockQuantity = 65
                },

                new Game
                {
                    GameId = 10,
                    Title = "Grand Theft Auto V",
                    GenreId = 4,
                    PublisherId = 2,
                    ReleaseDate = new DateTime(2013, 9, 17),
                    Platform = Platform.Xbox,
                    Price = 29.99m,
                    StockQuantity = 85
                },

                new Game
                {
                    GameId = 11,
                    Title = "The Elder Scrolls V: Skyrim",
                    GenreId = 3,
                    PublisherId = 8,
                    ReleaseDate = new DateTime(2011, 11, 11),
                    Platform = Platform.Playstation_4,
                    Price = 24.99m,
                    StockQuantity = 55
                },

                new Game
                {
                    GameId = 12,
                    Title = "Halo Infinite",
                    GenreId = 2,
                    PublisherId = 9,
                    ReleaseDate = new DateTime(2021, 12, 8),
                    Platform = Platform.Xbox,
                    Price = 49.99m,
                    StockQuantity = 40
                },

                 new Game
                 {
                     GameId = 13,
                     Title = "Horizon Zero Dawn",
                     GenreId = 3,
                     PublisherId = 10,
                     ReleaseDate = new DateTime(2020, 8, 7),
                     Platform = Platform.Playstation_5,
                     Price = 39.99m,
                     StockQuantity = 65
                 },

                new Game
                {
                    GameId = 14,
                    Title = "Among Us",
                    GenreId = 7,
                    PublisherId = 11,
                    ReleaseDate = new DateTime(2018, 6, 15),
                    Platform = Platform.Computer,
                    Price = 4.99m,
                    StockQuantity = 110
                },


                new Game
                {
                    GameId = 15,
                    Title = "Overwatch",
                    GenreId = 2,
                    PublisherId = 12,
                    ReleaseDate = new DateTime(2016, 5, 24),
                    Platform = Platform.Playstation_4,
                    Price = 19.99m,
                    StockQuantity = 75
                });
        }
    }
}