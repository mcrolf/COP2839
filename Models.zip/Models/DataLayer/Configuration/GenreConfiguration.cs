﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace VideoGameStore.Models
{
    internal class GenreConfiguration : IEntityTypeConfiguration<Genre>
    {
        public void Configure(EntityTypeBuilder<Genre> builder)
        {
            builder.HasData(
                                new Genre
                                {
                                    GenreId = 1,
                                    Name = "Sandbox",
                                    Description = "Open-world games where players have freedom to explore and create."
                                },

                                new Genre
                                {
                                    GenreId = 2,
                                    Name = "First-Person Shooter",
                                    Description = "Games that emphasize shooting from a first-person perspective."
                                },

                                new Genre
                                {
                                    GenreId = 3,
                                    Name = "Action RPG",
                                    Description = "Role-playing games with fast-paced action and combat elements."
                                },

                                new Genre
                                {
                                    GenreId = 4,
                                    Name = "Action-Adventure",
                                    Description = "Combines action gameplay with adventure elements and storytelling."
                                },

                                new Genre
                                {
                                    GenreId = 5,
                                    Name = "Sports",
                                    Description = "Simulations of real-world sports, such as soccer, basketball, and more."
                                },

                                new Genre
                                {
                                    GenreId = 6,
                                    Name = "Platformer",
                                    Description = "Games that focus on navigating platforms and obstacles."
                                },

                                new Genre
                                {
                                    GenreId = 7,
                                    Name = "Party",
                                    Description = "Multiplayer games designed for social gatherings and fun with friends."
                                },

                                new Genre
                                {
                                    GenreId = 8,
                                    Name = "Horror",
                                    Description = "Games that aim to scare and create a suspenseful atmosphere."
                                }
                );
        }
    }
}