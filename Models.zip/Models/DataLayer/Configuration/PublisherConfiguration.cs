﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace VideoGameStore.Models
{
    internal class PublisherConfiguration : IEntityTypeConfiguration<Publisher>
    {
        public void Configure(EntityTypeBuilder<Publisher> builder)
        {
            builder.HasData(
                                new Publisher
                                {
                                    PublisherId = 1,
                                    Name = "CD Projekt",
                                    Headquarters = "Warsaw, Poland",
                                    WebsiteURL = "https://www.cdprojekt.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 2,
                                    Name = "Rockstar Games",
                                    Headquarters = "New York City, USA",
                                    WebsiteURL = "https://www.rockstargames.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 3,
                                    Name = "Nintendo",
                                    Headquarters = "Kyoto, Japan",
                                    WebsiteURL = "https://www.nintendo.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 4,
                                    Name = "Ubisoft",
                                    Headquarters = "Montreuil, France",
                                    WebsiteURL = "https://www.ubisoft.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 5,
                                    Name = "Electronic Arts",
                                    Headquarters = "Redwood City, USA",
                                    WebsiteURL = "https://www.ea.com"
                                },


                                new Publisher
                                {
                                    PublisherId = 6,
                                    Name = "Mojang Studios",
                                    Headquarters = "Stockholm, Sweden",
                                    WebsiteURL = "https://www.minecraft.net"
                                },


                                 new Publisher
                                 {
                                     PublisherId = 7,
                                     Name = "Activision",
                                     Headquarters = "Santa Monica, USA",
                                     WebsiteURL = "https://www.activision.com"
                                 },

                                new Publisher
                                {
                                    PublisherId = 8,
                                    Name = "Bethesda",
                                    Headquarters = "Rockville, USA",
                                    WebsiteURL = "https://bethesda.net"
                                },

                                new Publisher
                                {
                                    PublisherId = 9,
                                    Name = "Microsoft",
                                    Headquarters = "Redmond, USA",
                                    WebsiteURL = "https://www.microsoft.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 10,
                                    Name = "Sony Interactive Entertainment",
                                    Headquarters = "San Mateo, USA",
                                    WebsiteURL = "https://www.sie.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 11,
                                    Name = "Innersloth",
                                    Headquarters = "Redmond, USA",
                                    WebsiteURL = "https://www.innersloth.com"
                                },

                                new Publisher
                                {
                                    PublisherId = 12,
                                    Name = "Blizzard Entertainment",
                                    Headquarters = "Irvine, USA",
                                    WebsiteURL = "https://www.blizzard.com"
                                }


            );


        }
    }
}